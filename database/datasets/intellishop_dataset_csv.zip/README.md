# IntelliShop synthetic supermarket dataset (5 years)

**Period:** 2021-11-01 → 2026-11-25 (1,851 days) · **Currency:** BDT (৳) · **Format:** one .csv per table, same column names as your Laravel migrations.

## Important: this is synthetic data
All records are synthetic and do not represent any real supermarket, customer, or transaction. The dataset models a fictional Dhaka supermarket chain:
6 Dhaka branches (Dhanmondi, Gulshan, Uttara, Mirpur, Mohammadpur [opens Aug 2022], Bashundhara [opens Mar 2023]),
122 Bangladeshi supershop products (rice, dal, mustard oil, hilsa, Aarong milk, Radhuni spices, Pran/Olympic snacks…), 21 suppliers, 9,000 customers.
Brand names are used only to make the catalogue realistic; phone numbers, emails and addresses are fake.

## What is modelled
- Weekly pattern (Thu/Fri peak), salary-week bump, ~6 %/yr growth, new-branch ramp-up
- Ramadan / Eid-ul-Fitr / Eid-ul-Adha / Pohela Boishakh demand spikes; winter, summer, mango and hilsa seasonality
- Price inflation (~7–10 %/yr), so `sale_items.unit_price` is the price on the sale date
- Promotions (`discounts`) that actually lift demand and reduce line prices
- Jul–Aug 2024 curfew/shutdown dip (useful for anomaly detection)
- Co-purchase patterns (rice+dal, tea+sugar, bread+eggs…) for market-basket rules
- Batch-level stock (FEFO): purchase orders → partial/late deliveries → batches → sales → expiry, damage, cycle counts, transfers. **Stock ledger reconciles exactly** (inventory = sum of batch remaining; no negative stock).
- Stock-outs (~3.45 % of demand lost) and spoilage (~5.1 % of units sold) are realistic, not zero.

## Scale


| Year | Revenue |
|---|---|
| 2021 | ৳1,689,748 (partial: Nov–Dec) |
| 2022 | ৳18,737,843 |
| 2023 | ৳28,878,652 |
| 2024 | ৳33,535,463 |
| 2025 | ৳40,162,505 |
| 2026 | ৳41,126,756 (to 25 Nov) |

## Conventions
- Dates/timestamps are text `YYYY-MM-DD` / `YYYY-MM-DD HH:MM:SS` (import-ready for MySQL).
- `payment_method`: cash / card / mobile (bKash/Nagad). `sales.total_amount = subtotal − discount_amount + tax_amount` (5 % VAT on processed goods).
- All users share the password `password` (bcrypt hash included); first 7 users match your `UserSeeder` emails.
- `risk_level` is upper-case (HIGH/MEDIUM/LOW) as your app expects. `system_settings` is copied from your `SettingsSeeder`.
- ML tables (`model_runs`, `demand_forecasts`, `stock_predictions`, `sales_anomalies`, `market_basket_rules`, `ai_recommendations`, `markdown_recommendations`, `cycle_counts`) are computed from this data as of 2026-11-25 – you can truncate them and let your own analytics-service regenerate them.
- Not included: `sessions`, `cache`, `jobs` (framework tables).

## Import order (foreign keys)
roles → branches → users → units → categories → brands → products → suppliers → product_suppliers → customers → discounts (batch_id rows after inventory_batches) → purchase_orders → purchase_order_items → purchases → inventory_batches → inventory → inventory_transactions → stock_transfers → sales → sale_items → sale_item_batches → everything else.
(`branches.manager_id` and `users.branch_id` reference each other – load with FK checks off.)

## Files and row counts
| File | Rows |
|---|---|
| `ai_recommendations.csv` | 720 |
| `audit_logs.csv` | 17,820 |
| `branches.csv` | 6 |
| `brands.csv` | 56 |
| `categories.csv` | 42 |
| `customers.csv` | 9,000 |
| `cycle_counts.csv` | 809 |
| `demand_forecasts.csv` | 9,660 |
| `discounts.csv` | 300 |
| `inventory.csv` | 690 |
| `inventory_batches.csv` | 148,779 |
| `inventory_transactions.csv` | 1,000,000 |
| `markdown_recommendations.csv` | 67 |
| `market_basket_rules.csv` | 91 |
| `model_runs.csv` | 3,450 |
| `product_promotions.csv` | 22,845 |
| `product_suppliers.csv` | 296 |
| `products.csv` | 122 |
| `purchase_order_items.csv` | 152,861 |
| `purchase_orders.csv` | 71,723 |
| `purchases.csv` | 148,662 |
| `roles.csv` | 7 |
| `sale_item_batches.csv` | 844,597 |
| `sale_items.csv` | 819,228 |
| `sales.csv` | 250,417 |
| `sales_anomalies.csv` | 1,471 |
| `stock_predictions.csv` | 690 |
| `stock_transfers.csv` | 98 |
| `suppliers.csv` | 21 |
| `system_settings.csv` | 32 |
| `units.csv` | 9 |
| `users.csv` | 57 |

## CSV notes
UTF-8, comma-separated, header row, **empty field = NULL**. `inventory_transactions.csv` is a single file (1,023,112 rows).
MySQL example: `LOAD DATA LOCAL INFILE 'sales.csv' INTO TABLE sales FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\r\n' IGNORE 1 LINES;`
(for NULL columns, add a SET clause with NULLIF(@col,'') or replace empty fields with \N).
